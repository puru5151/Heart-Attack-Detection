﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;

public partial class Home : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["connection_string"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select id,num from dataset", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        int count = 0;
        int count1 = 0;
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                string id = row["id"].ToString();
                string a = row["num"].ToString();
                SqlCommand cmd1 = new SqlCommand("select pid,result from id3_compare", con);
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    foreach (DataRow item in dt1.Rows)
                    {
                        string id1 = item["pid"].ToString();
                        string b = item["result"].ToString();
                        if (id == id1 && a == b)
                        {
                            count++;
                        }
                    }
                }
                SqlCommand cmd2 = new SqlCommand("select pid,result from naive_compare", con);
                SqlDataAdapter sda2 = new SqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                sda2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    foreach (DataRow item1 in dt2.Rows)
                    {
                        string id2 = item1["pid"].ToString();
                        string d = item1["result"].ToString();
                        if (id == id2 && a == d)
                        {
                            count1++;
                        }
                    }
                }




            }
            int c1=count;
            int e1 = count1;

            DataTable dt3 = new DataTable();
            dt3.Columns.Add("algo");
            dt3.Columns.Add("value");
            dt3.Rows.Add(new Object[] { "ID3", c1 });
            dt3.Rows.Add(new Object[] { "Naive", e1 });

            string[] x = new string[dt3.Rows.Count];
            double[] y = new double[dt3.Rows.Count];

            for (int i = 0; i < dt3.Rows.Count; i++)
            {
                x[i] = dt3.Rows[i].ItemArray[0].ToString();
                y[i] = Convert.ToDouble(dt3.Rows[i].ItemArray[1]);
                Chart2.ChartAreas[0].AxisX.Interval = 1;
                Chart2.Series["Series1"].Label = "";
                Chart2.Series["Series1"].Points.DataBindXY(x, y);

            }
        }
    }
}