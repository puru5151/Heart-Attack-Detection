﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using ProbabilityFunctions;
using System.Net.Mail;

public partial class SetRangeForSensor : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["connection_string"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
            Label5.Visible = false;
            Label6.Visible = false;
            Label7.Visible = false;
            Label8.Visible = false;
            Label9.Visible = false;
            Label10.Visible = false;
            Label11.Visible = false;
            Label12.Visible = false;
            Label13.Visible = false;
            Label14.Visible = false;
            Label15.Visible = false;
            Label16.Visible = false;
            Label17.Visible = false;
            Label18.Visible = false;
            Label19.Visible = false;
            Label20.Visible = false;
            Label21.Visible = false;
            Label22.Visible = false;
            Label25.Visible = false;
            Label24.Visible = false;
            Label23.Visible = false;


        }
    }
    protected void SetRange_Click(object sender, EventArgs e)
    {
        Label23.Visible = true;
        Label24.Visible = true;
        Label25.Visible = true;
        #region
        double age2 = Convert.ToDouble(Label1.Text);       
        double trestbps = Convert.ToDouble(Label4.Text);
        double chol = Convert.ToDouble(Label5.Text);       
        double thalach = Convert.ToDouble(Label8.Text);      
        double oldpeak = Convert.ToDouble(Label10.Text);
       


     

        
        string age1 = "";
        string trestbps1 = "";
        string chol1 = "";
        string thalach1 = "";
        string oldpeak1 = "";
     
        if (age2 > 21 && age2 < 30)
        {
            age1 = "1";
        }
        else if (age2 > 31 && age2 < 40)
        {
            age1 = "2";
        }
        else if (age2 > 41 && age2 < 50)
        {
            age1 = "3";
        }
        else if (age2 > 51 && age2 < 60)
        {
            age1 = "4";
        }
        else if (age2 > 61 && age2 < 70)
        {
            age1 = "5";
        }
        else if (age2 > 71 && age2 < 80)
        {
            age1 = "6";
        }
        //trestbps
        if (trestbps > 90 && trestbps < 104)
        {
            trestbps1 = "1";
        }
        else if (trestbps > 105 && trestbps < 119)
        {
            trestbps1 = "2";
        }
        else if (trestbps > 120 && trestbps < 134)
        {
            trestbps1 = "3";
        }
        else if (trestbps > 135 && trestbps < 149)
        {
            trestbps1 = "4";
        }
        else if (trestbps > 150 && trestbps < 164)
        {
            trestbps1 = "5";
        }
        else if (trestbps > 165 && trestbps < 189)
        {
            trestbps1 = "6";
        }
        else if (trestbps > 190 && trestbps < 204)
        {
            trestbps1 = "7";
        }

        //chol
        if (chol > 125 && chol < 174)
        {
            chol1 = "1";
        }
        else if (chol > 175 && chol < 224)
        {
            chol1 = "2";
        }
        else if (chol > 225 && chol < 274)
        {
            chol1 = "3";
        }
        else if (chol > 275 && chol < 324)
        {
            chol1 = "4";
        }
        else if (chol > 324 && chol < 375)
        {
            chol1 = "5";
        }
        else if (chol > 375 && chol < 425)
        {
            chol1 = "6";
        }
        else if (chol > 425 && chol < 475)
        {
            chol1 = "7";
        }
        else if (chol > 475 && chol < 524)
        {
            chol1 = "8";
        }
        else if (chol > 525 && chol < 544)
        {
            chol1 = "9";
        }

        //thalach

        if (thalach > 70 && thalach < 100)
        {
            thalach1 = "1";
        }
        else if (thalach > 101 && thalach < 130)
        {
            thalach1 = "2";
        }
        else if (thalach > 131 && thalach < 160)
        {
            thalach1 = "3";
        }
        else if (thalach > 161 && thalach < 190)
        {
            thalach1 = "4";
        }
        else if (thalach > 191 && thalach < 220)
        {
            thalach1 = "5";
        }

        //oldpeak
        if (oldpeak > 0 && oldpeak < 0.9)
        {
            oldpeak1 = "1";
        }
        else if (oldpeak > 1 && oldpeak < 1.9)
        {
            oldpeak1 = "2";
        }
        else if (oldpeak > 2 && oldpeak < 2.9)
        {
            oldpeak1 = "3";
        }
        else if (oldpeak > 3 && oldpeak < 3.9)
        {
            oldpeak1 = "4";
        }
        else if (oldpeak > 4 && oldpeak < 4.9)
        {
            oldpeak1 = "5";
        }
        else if (oldpeak > 5 && oldpeak < 6.2)
        {
            oldpeak1 = "6";
        }
        #endregion

        string age=age1;
        string sex=Label2.Text;
        string cp=Label3.Text;
        string tb=trestbps1;
        string cl=chol1;
        string fbs=Label6.Text;
        string rg=Label7.Text;
        string th=thalach1;
        string ex=Label9.Text;
        string old=oldpeak1;
        string sp=Label11.Text;
        string ca=Label12.Text;
        string thl=Label13.Text;
       // string num="";
        #region
        string a="";
        if (thl == "3")
        {
            if (ca == "0")
            {
                if (th == "4")
                {
                    if (cl == "5")
                    {
                        if (age == "0")
                        {
                            Label23.Text = "heart disease is present";
                        }
                        else
                        {
                            Label23.Text = "heart disease is not present";                            
                        }
                    }
                    else
                    {
                        Label23.Text = "heart disease is not present";
                    }
                }
                else
                {
                    if (old == "1")
                    {
                        Label23.Text = "heart disease is not present";
                    }
                    else
                    {
                        if (cp == "4")
                        {
                            if (rg == "2")
                            {
                                if (tb == "5")
                                {
                                    Label23.Text = "heart disease is present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                            }
                            else
                            {
                                if (sp == "2")
                                {
                                    if (age == "0")
                                    {
                                        Label23.Text = "heart disease is not present";
                                    }
                                    else
                                    {
                                        if (sex == "1")
                                        {
                                            Label23.Text = "heart disease 2 is present";
                                        }
                                        else
                                        {
                                            if (cl == "5")
                                            {
                                                Label23.Text = "heart disease 2 is present";
                                            }
                                            else
                                            {
                                                Label23.Text = "heart disease is present";
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                            }
                        }
                        else
                        {
                            if (sex == "1")
                            {
                                if (tb == "3")
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    if (ex == "0")
                                    {
                                        if (sp == "2")
                                        {
                                            Label23.Text = "heart disease is present";
                                        }
                                        else
                                        {
                                            if (age == "0")
                                            {
                                                Label23.Text = "heart disease is not present";
                                            }
                                            else
                                            {
                                                if (tb == "0")
                                                {
                                                    Label23.Text = "heart disease is not present";
                                                }
                                                else
                                                {
                                                    if (age == "3")
                                                    {
                                                        if (tb == "4")
                                                        {
                                                            Label23.Text = "heart disease is not present";
                                                        }
                                                        else
                                                        {
                                                            Label23.Text = "heart disease is present";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        Label23.Text = "heart disease is present";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Label23.Text = "heart disease is not present";
                                    }
                                }
                            }
                            else
                            {
                                Label23.Text = "heart disease is not present";
                            }
                        }
                    }
                }
            }
            else
            {
                if (cp == "4")
                {
                    if (sex == "1")
                    {
                        if (age == "5")
                        {
                            if (tb == "5")
                            {
                                Label23.Text = "heart disease 2 is present";
                            }
                            else
                            {
                                if (tb == "2")
                                {
                                    Label23.Text = "heart disease 2 is present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease 3 is  present";
                                }
                            }
                        }
                        else
                        {
                            if (ex == "0")
                            {
                                if (th == "3")
                                {
                                    Label23.Text = "heart disease 2 is present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease is present";
                                }
                            }
                            else
                            {
                                if (age == "4")
                                {
                                    if (cl == "3")
                                    {
                                        Label23.Text = "heart disease is present";
                                    }
                                    else
                                    {
                                        Label23.Text = "heart disease 3 is  present";
                                    }
                                }
                                else
                                {
                                    if (age == "3")
                                    {
                                        Label23.Text = "heart disease is present";
                                    }
                                    else
                                    {
                                        Label23.Text = "heart disease 4 is present";
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (tb == "4")
                        {
                            if (cl == "3")
                            {
                                Label23.Text = "heart disease 3 is  present";
                            }
                            else
                            {
                                Label23.Text = "heart disease 2 is present";
                            }
                        }
                        else
                        {
                            if (cl == "3")
                            {
                                Label23.Text = "heart disease is present";
                            }
                            else
                            {
                                Label23.Text = "heart disease is not present";
                            }
                        }
                    }
                }
                else
                {
                    if (old == "3")
                    {
                        Label23.Text = "heart disease 2 is present";
                    }
                    else
                    {
                        if (th == "3")
                        {
                            if (ca == "2")
                            {
                                if (age == "5")
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease 3 is  present";
                                }
                            }
                            else
                            {
                                Label23.Text = "heart disease is not present";
                            }
                        }
                        else
                        {
                            if (age == "4")
                            {
                                if (cp == "3")
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease is present";
                                }
                            }
                            else
                            {
                                if (cl == "1")
                                {
                                    Label23.Text = "heart disease is present";
                                }
                                else
                                {
                                    if (old == "2")
                                    {
                                        if (age == "5")
                                        {
                                            Label23.Text = "heart disease is present";
                                        }
                                        else
                                        {
                                            Label23.Text = "heart disease is not present";
                                        }
                                    }
                                    else
                                    {
                                        Label23.Text = "heart disease is not present";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            if (ca == "0")
            {
                if (ex == "0")
                {
                    if (th == "2")
                    {
                        Label23.Text = "heart disease 4 is present";
                    }
                    else
                    {
                        if (age == "2")
                        {
                            Label23.Text = "heart disease 3 is  present";
                        }
                        else
                        {
                            if (cl == "0")
                            {
                                if (age == "5")
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease 3 is  present";
                                }
                            }
                            else
                            {
                                if (fbs == "1")
                                {
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    if (thl == "6")
                                    {
                                        Label23.Text = "heart disease is not present";
                                    }
                                    else
                                    {
                                        if (age == "0")
                                        {
                                            Label23.Text = "heart disease is present";
                                        }
                                        else
                                        {
                                            if (tb == "5")
                                            {
                                                Label23.Text = "heart disease is present";
                                            }
                                            else
                                            {
                                                if (cl == "2")
                                                {
                                                    Label23.Text = "heart disease is not present";
                                                }
                                                else
                                                {
                                                    if (cp == "3")
                                                    {
                                                        Label23.Text = "heart disease is not present";
                                                    }
                                                    else
                                                    {
                                                        if (age == "3")
                                                        {
                                                            if (cp == "2")
                                                            {
                                                                if (tb == "0")
                                                                {
                                                                    Label23.Text = "heart disease is not present";
                                                                }
                                                                else
                                                                {
                                                                    Label23.Text = "heart disease is present";
                                                                }
                                                            }
                                                            else
                                                            {
                                                                Label23.Text = "heart disease is not present";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (tb == "3")
                                                            {
                                                                Label23.Text = "heart disease is present";

                                                            }
                                                            else
                                                            {
                                                                if (cl == "3")
                                                                {
                                                                    Label23.Text = "heart disease is not present";
                                                                }
                                                                else
                                                                {
                                                                    if (cp == "1")
                                                                    {
                                                                        Label23.Text = "heart disease is present";

                                                                    }
                                                                    else
                                                                    {
                                                                        Label23.Text = "heart disease is not present";
                                                                    }

                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {

                    if (cl == "4")
                    {
                        if (th == "2")
                        {
                            Label23.Text = "heart disease 2 is present";
                        }
                        else
                        {
                            if (sex == "1")
                            {
                                Label23.Text = "heart disease is present";
                            }
                            else
                            {
                                if (tb == "4")
                                {
                                    Label23.Text = "heart disease is present";
                                }
                                else
                                {
                                    Label23.Text = "heart disease 2 is present";
                                }
                            }
                        }
                    }
                    else
                    {
                        if (th == "3")
                        {
                            if (cp == "4")
                            {
                                if (cl == "5")
                                {
                                    Label23.Text = "heart disease 2 is present";
                                }
                                else
                                {
                                    if (tb == "0")
                                    {
                                        Label23.Text = "heart disease 2 is present";
                                    }
                                    else
                                    {
                                        Label23.Text = "heart disease is present";
                                    }

                                }
                            }
                            else
                            {
                                if (age == "5")
                                {
                                    a = "3";
                                    Label23.Text = "heart disease 3 is  present";
                                }
                                else
                                {
                                    a = "0";
                                    Label23.Text = "heart disease is not present";

                                }
                            }
                        }
                        else
                        {
                            if (rg == "2")
                            {
                                if (age == "4")
                                {
                                    if (tb == "4")
                                    {
                                        a = "0";
                                        Label23.Text = "heart disease is not present";
                                    }
                                    else
                                    {
                                        a = "3";
                                        Label23.Text = "heart disease 3 is  present";
                                    }
                                }
                                else
                                {
                                    a = "3";
                                    Label23.Text = "heart disease 3 is  present";

                                }
                            }
                            else
                            {
                                if (cl == "2")
                                {

                                    if (age == "2")
                                    {
                                        a = "1";
                                        Label23.Text = "heart disease is present";
                                    }
                                    else
                                    {
                                        if (old == "6")
                                        {
                                            a = "3";
                                            Label23.Text = "heart disease 3 is  present";
                                        }
                                        else
                                        {
                                            a = "0";
                                            Label23.Text = "heart disease is not present";
                                        }
                                    }
                                }
                                else
                                {

                                    if (age == "4")
                                    {
                                        a = "1";
                                        Label23.Text = "heart disease is present";
                                    }
                                    else
                                    {
                                        a = "4";
                                        Label23.Text = "heart disease 4 is present";

                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (rg == "0")
                {
                    if (sp == "2")
                    {
                        if (tb == "3")
                        {
                            if (cp == "4")
                            {
                                if (age == "5")
                                {
                                    if (fbs == "1")
                                    {
                                        a = "3";
                                        Label23.Text = "heart disease 3 is  present";
                                    }
                                    else
                                    {
                                        a = "0";
                                        Label23.Text = "heart disease is not present";
                                    }
                                }
                                else
                                {
                                    a = "3";
                                    Label23.Text = "heart disease 3 is  present";
                                }
                            }
                            else
                            {
                                if (ca == "3")
                                {
                                    a = "0";
                                    Label23.Text = "heart disease is not present";

                                }
                                else
                                {
                                    a = "2";
                                    Label23.Text = "heart disease 2 is present";
                                }
                            }
                        }
                        else
                        {

                            if (th == "1")
                            {
                                a = "1";
                                Label23.Text = "heart disease is present";

                            }
                            else
                            {
                                if (tb == "4")
                                {
                                    if (ca == "2")
                                    {
                                        a = "2";
                                        Label23.Text = "heart disease 2 is present";
                                    }
                                    else
                                    {
                                        if (cl == "4")
                                        {
                                            a = "3";
                                            Label23.Text = "heart disease 3 is  present";
                                        }
                                        else
                                        {
                                            a = "1";
                                            Label23.Text = "heart disease is present";
                                        }
                                    }
                                }
                                else
                                {

                                    if (cp == "3")
                                    {
                                        a = "3";
                                        Label23.Text = "heart disease 3 is  present";

                                    }
                                    else
                                    {
                                        if (sex == "1")
                                        {
                                            if (old == "3")
                                            {
                                                a = "3";
                                                Label23.Text = "heart disease 3 is  present";
                                            }
                                            else
                                            {
                                                a = "2";
                                                Label23.Text = "heart disease 2 is present";
                                            }
                                        }
                                        else
                                        {
                                            a = "3";
                                            Label23.Text = "heart disease 3 is  present";
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (tb == "3")
                        {
                            if (cl == "3")
                            {
                                a = "1";
                                Label23.Text = "heart disease is present";
                            }
                            else
                            {
                                a = "3";
                                Label23.Text = "heart disease 3 is  present";
                            }
                        }
                        else
                        {
                            if (cp == "4")
                            {
                                if (ca == "3")
                                {
                                    a = "0";
                                    Label23.Text = "heart disease is not present";
                                }
                                else
                                {
                                    a = "2";
                                    Label23.Text = "heart disease 2 is present";
                                }
                            }
                            else
                            {
                                a = "0";
                                Label23.Text = "heart disease is not present";
                            }
                        }
                    }
                }
                else
                {
                    if (old == "2")
                    {
                        if (age == "5")
                        {
                            if (cl == "3")
                            {
                                a = "2";
                                Label23.Text = "heart disease 2 is present";
                            }
                            else
                            {
                                a = "3";
                                Label23.Text = "heart disease 3 is  present";

                            }
                        }
                        else
                        {
                            a = "2";
                            Label23.Text = "heart disease 2 is present";
                        }
                    }
                    else
                    {
                        if (sex == "1")
                        {
                            if (ca == "1")
                            {

                                if (tb == "5")
                                {
                                    a = "4";
                                    Label23.Text = "heart disease 4 is present";

                                }
                                else
                                {
                                    if (tb == "2")
                                    {
                                        a = "4";
                                        Label23.Text = "heart disease 4 is present";

                                    }
                                    else
                                    {
                                        if (age == "5")
                                        {
                                            a = "2";
                                            Label23.Text = "heart disease 2 is present";
                                        }
                                        else
                                        {
                                            if (fbs == "1")
                                            {
                                                a = "2";
                                                Label23.Text = "heart disease 2 is present";
                                            }
                                            else
                                            {
                                                a = "1";
                                                Label23.Text = "heart disease is present";

                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (tb == "4")
                                {
                                    if (age == "3")
                                    {
                                        a = "3";
                                        Label23.Text = "heart disease 3 is  present";
                                    }
                                    else
                                    {
                                        if (thl == "6")
                                        {
                                            a = "4";
                                            Label23.Text = "heart disease 4 is present";
                                        }
                                        else
                                        {
                                            a = "2";
                                            Label23.Text = "heart disease 2 is present";
                                        }
                                    }
                                }
                                else
                                {
                                    if (age == "5")
                                    {
                                        a = "1";
                                        Label23.Text = "heart disease is present";
                                    }
                                    else
                                    {
                                        if (cl == "4")
                                        {
                                            if (tb == "3")
                                            {
                                                a = "1";
                                                Label23.Text = "heart disease is present";
                                            }
                                            else
                                            {
                                                a = "4";
                                                Label23.Text = "heart disease 4 is present";
                                            }
                                        }
                                        else
                                        {
                                            if (old == "3")
                                            {
                                                if (age == "0")
                                                {
                                                    a = "4";
                                                    Label23.Text = "heart disease 4 is present";
                                                }
                                                else
                                                {
                                                    a = "1";
                                                    Label23.Text = "heart disease is present";
                                                }
                                            }
                                            else
                                            {
                                                a = "3";
                                                Label23.Text = "heart disease 3 is  present";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (age == "5")
                            {
                                if (tb == "5")
                                {
                                    a = "3";
                                    Label23.Text = "heart disease 3 is  present";
                                }
                                else
                                {
                                    a = "4";
                                    Label23.Text = "heart disease 4 is present";
                                }
                            }
                            else
                            {
                                if (tb == "6")
                                {
                                    a = "2";
                                    Label23.Text = "heart disease 2 is present";
                                }
                                else
                                {
                                    if (cl == "6")
                                    {
                                        a = "2";
                                        Label23.Text = "heart disease 2 is present";
                                    }
                                    else
                                    {
                                        a = "3";
                                        Label23.Text = "heart disease 3 is  present";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion
        string b = Label23.Text;
        if (b.Equals("heart disease 3 is  present"))
        {

            a = "3";
            SqlCommand cmd = new SqlCommand("insert into id3_compare(pid,result)values(@pid,@result)",con);
            cmd.Parameters.AddWithValue("@pid",DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@result",a);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        else if (b.Equals("heart disease 2 is present"))
        {
            a = "2";
            SqlCommand cmd = new SqlCommand("insert into id3_compare(pid,result)values(@pid,@result)",con);
            cmd.Parameters.AddWithValue("@pid",DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@result",a);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        else if (b.Equals("heart disease 4 is present"))
        {
            a = "4";
            SqlCommand cmd = new SqlCommand("insert into id3_compare(pid,result)values(@pid,@result)",con);
            cmd.Parameters.AddWithValue("@pid",DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@result",a);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        else if (b.Equals("heart disease is present"))
        {
            a = "1";
            SqlCommand cmd = new SqlCommand("insert into id3_compare(pid,result)values(@pid,@result)",con);
            cmd.Parameters.AddWithValue("@pid",DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@result",a);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        else if (b.Equals("heart disease is not present"))
        {
            a = "0";
            SqlCommand cmd = new SqlCommand("insert into id3_compare(pid,result)values(@pid,@result)",con);
            cmd.Parameters.AddWithValue("@pid",DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@result",a);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        double heart = Convert.ToDouble(Label22.Text);
        double temp = Convert.ToDouble(Label21.Text);

        if(heart>59 && heart<100)
        {
            Label24.Text="and NORMAL and ";
        }
        else if(heart>0 && heart<58)
        {
            Label24.Text="and sinus bradycardia and ";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go below threshold value of heart rate with "+heart+" BPM";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }
        else if(heart>101)
        {
            Label24.Text = "and sinus tachycardia and ";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The HEART RATE of person go beyond threshold value of heart rate with "+heart+"BPM";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }


        if (temp > 31 && temp < 36)
        {
            Label25.Text = "NORMAL";
        }
        else if (temp > 37 && temp < 38)
        {
            Label25.Text = "FEBRILE";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "FEBRILE";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }
        else if (temp > 39 && temp < 100)
        {
            Label25.Text = "HYPERTHERIMIA";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go beyond threshold value of body temperature with "+temp+" degree  Celsius";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }

        else if (temp > 0 && temp < 29)
        {
            Label25.Text = "HYPOTHERMIA";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go below threshold value of body temperature with "+temp+" degree Celsius";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label1.Visible = true;
        Label2.Visible = true;
        Label3.Visible = true;
        Label4.Visible = true;
        Label5.Visible = true;
        Label6.Visible = true;
        Label7.Visible = true;
        Label8.Visible = true;
        Label9.Visible = true;
        Label10.Visible = true;
        Label11.Visible = true;
        Label12.Visible = true;
        Label13.Visible = true;
        Label14.Visible = true;
        Label15.Visible = true;
        Label16.Visible = true;
        Label17.Visible = true;
        Label18.Visible = true;
        Label19.Visible = true;
        Label20.Visible = true;
        Label21.Visible = true;
        Label22.Visible = true;
        SqlCommand cmd = new SqlCommand("select * from dataset1 where Patient_name=@Patient_name", con);
        cmd.Parameters.AddWithValue("@Patient_name", DropDownList1.SelectedItem.Text);
        SqlDataAdapter dsa = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        dsa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            SqlCommand cmd1 = new SqlCommand("select top 1 bpm,btemp from data order by id  desc", con);
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);


            Label1.Text = dt.Rows[0]["age"].ToString();
            Label2.Text = dt.Rows[0]["sex"].ToString();
            Label3.Text = dt.Rows[0]["cp"].ToString();
            Label4.Text = dt.Rows[0]["trestbps"].ToString();
            Label5.Text = dt.Rows[0]["chol"].ToString();
            Label6.Text = dt.Rows[0]["fbs"].ToString();
            Label7.Text = dt.Rows[0]["restecg"].ToString();
            Label8.Text = dt.Rows[0]["thalach"].ToString();
            Label9.Text = dt.Rows[0]["exang"].ToString();
            Label10.Text = dt.Rows[0]["oldpeak"].ToString();
            Label11.Text = dt.Rows[0]["slope"].ToString();
            Label12.Text = dt.Rows[0]["ca"].ToString();
            Label13.Text = dt.Rows[0]["thal"].ToString();
            Label14.Text = dt.Rows[0]["smoking_hab"].ToString();
            Label15.Text = dt.Rows[0]["alcoholic"].ToString();
            Label16.Text = dt.Rows[0]["physical_activity"].ToString();
            Label17.Text = dt.Rows[0]["diet"].ToString();
            Label18.Text = dt.Rows[0]["obesity"].ToString();
            Label19.Text = dt.Rows[0]["famhist"].ToString();
            Label20.Text = dt.Rows[0]["stress"].ToString();
            Label21.Text = dt1.Rows[0]["btemp"].ToString();
            Label22.Text = dt1.Rows[0]["bpm"].ToString();
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Label23.Visible = true;
        Label24.Visible = true;
        Label25.Visible = true;
        SqlCommand cmd1 = new SqlCommand("truncate table temp_z", con);
        con.Open();
        cmd1.ExecuteNonQuery();
        con.Close();
        SqlCommand cmd = new SqlCommand("select num,trestbps,chol,thalach,oldpeak from Sheet1$", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        Classifier classifier = new Classifier();
        classifier.TrainClassifier(dt);
        double trestbps = Convert.ToDouble(Label4.Text);
        double chol = Convert.ToDouble(Label5.Text);
        double thalach = Convert.ToDouble(Label8.Text);
        double oldpeak = Convert.ToDouble(Label10.Text);
        string val = classifier.Classify(new double[] { trestbps, chol, thalach, oldpeak });
        if (val == "0")
        {
            SqlCommand cmd11 = new SqlCommand("insert into naive_compare(pid,result)values(@pid,@result)", con);
            cmd11.Parameters.AddWithValue("@pid", DropDownList1.SelectedValue);
            cmd11.Parameters.AddWithValue("@result", val);
            con.Open();
            cmd11.ExecuteNonQuery();
            con.Close();
            Label23.Text = "heart disease is not present";
        }
        else if (val == "1")
        {
            SqlCommand cmd11 = new SqlCommand("insert into naive_compare(pid,result)values(@pid,@result)", con);
            cmd11.Parameters.AddWithValue("@pid", DropDownList1.SelectedValue);
            cmd11.Parameters.AddWithValue("@result", val);
            con.Open();
            cmd11.ExecuteNonQuery();
            con.Close();
            Label23.Text = "heart disease is present";
        }
        else if (val == "2")
        {
            SqlCommand cmd11 = new SqlCommand("insert into naive_compare(pid,result)values(@pid,@result)", con);
            cmd11.Parameters.AddWithValue("@pid", DropDownList1.SelectedValue);
            cmd11.Parameters.AddWithValue("@result", val);
            con.Open();
            cmd11.ExecuteNonQuery();
            con.Close();
            Label23.Text = "heart disease 2 is present";
        }
        else if (val == "3")
        {
            SqlCommand cmd11 = new SqlCommand("insert into naive_compare(pid,result)values(@pid,@result)", con);
            cmd11.Parameters.AddWithValue("@pid", DropDownList1.SelectedValue);
            cmd11.Parameters.AddWithValue("@result", val);
            con.Open();
            cmd11.ExecuteNonQuery();
            con.Close();
            Label23.Text = "heart disease 3 is  present";
        }
        else if (val == "4")
        {
            SqlCommand cmd11 = new SqlCommand("insert into naive_compare(pid,result)values(@pid,@result)", con);
            cmd11.Parameters.AddWithValue("@pid", DropDownList1.SelectedValue);
            cmd11.Parameters.AddWithValue("@result", val);
            con.Open();
            cmd11.ExecuteNonQuery();
            con.Close();
            Label23.Text = "heart disease 4 is present";
        }
        double heart = Convert.ToDouble(Label22.Text);
        double temp = Convert.ToDouble(Label21.Text);

        if (heart > 59 && heart < 100)
        {
            Label24.Text = "and NORMAL and ";
        }
        else if (heart > 0 && heart < 58)
        {
            Label24.Text = "and sinus bradycardia and ";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go below threshold value of heart rate with " + heart + " BPM";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }
        else if (heart > 101)
        {
            Label24.Text = "and sinus tachycardia and ";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The HEART RATE of person go beyond threshold value of heart rate with " + heart + "BPM";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }


        if (temp > 31 && temp < 36)
        {
            Label25.Text = "NORMAL";
        }
        else if (temp > 37 && temp < 38)
        {
            Label25.Text = "FEBRILE";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "FEBRILE!!";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }
        else if (temp > 39 && temp < 100)
        {
            Label25.Text = "HYPERTHERIMIA";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go beyond threshold value of body temperature with " + temp + " degree  Celsius";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }

        else if (temp > 0 && temp < 29)
        {
            Label25.Text = "HYPOTHERMIA";
            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient("my-demo.in");

            //mail.From = new MailAddress("test@my-demo.in");
            //mail.Subject = "Alert";
            //mail.To.Add("purveshdave619@gmail.com");
            //mail.Body = "The body temperature of person go below threshold value of body temperature with " + temp + " degree Celsius";

            //SmtpServer.Port = 25;
            //SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

            //SmtpServer.Send(mail);
        }
    }
}