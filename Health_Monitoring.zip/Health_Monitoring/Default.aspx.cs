﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    public static string cs = WebConfigurationManager.ConnectionStrings["connection_string"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(cs);
        if (!IsPostBack)
        {
          
            SqlCommand cmd = new SqlCommand("truncate table dataset", conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            course1();
        }
    }

    public void course1()
    {
        SqlConnection conn = new SqlConnection(cs);
        //   string ExcelContentType = "application/vnd.ms-excel";
        string Excel2010ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        //Save file path 
        string path = Directory.GetFiles(@"C:\Users\pariv\Desktop\FINAL YEAR PROJECT\Health_Monitoring", "1.xlsx").Single();
        //string path = string.Concat(Server.MapPath("~/TempFiles/"), FileUpload1.FileName);
        //Save File as Temp then you can delete it if you want 
        // FileUpload1.SaveAs(path);
        //string path = @"C:\Users\Johnney\Desktop\ExcelData.xls"; 
        //For Office Excel 2010  please take a look to the followng link  http://social.msdn.microsoft.com/Forums/en-US/exceldev/thread/0f03c2de-3ee2-475f-b6a2-f4efb97de302/#ae1e6748-297d-4c6e-8f1e-8108f438e62e 
        string excelConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=Excel 8.0", path);

        // Create Connection to Excel Workbook 
        using (OleDbConnection connection1 =
                     new OleDbConnection(excelConnectionString))
        {
            OleDbCommand command = new OleDbCommand("Select * FROM [Sheet1$]", connection1);

            connection1.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter oda = new OleDbDataAdapter(command);
            connection1.Close();
            oda.Fill(ds);
            DataTable Exceldt = ds.Tables[0];

            SqlBulkCopy objbulk = new SqlBulkCopy(conn);
            //assigning Destination table name    
            objbulk.DestinationTableName = "dataset";
            //Mapping Table column    
            objbulk.ColumnMappings.Add("Patient_name", "Patient_name");
            objbulk.ColumnMappings.Add("age", "age");
            objbulk.ColumnMappings.Add("sex", "sex");
            objbulk.ColumnMappings.Add("cp", "cp");
            objbulk.ColumnMappings.Add("trestbps", "trestbps");
            objbulk.ColumnMappings.Add("chol", "chol");
            objbulk.ColumnMappings.Add("fbs", "fbs");
            objbulk.ColumnMappings.Add("restecg", "restecg");
            objbulk.ColumnMappings.Add("thalach", "thalach");
            objbulk.ColumnMappings.Add("exang", "exang");
            objbulk.ColumnMappings.Add("oldpeak", "oldpeak");
            objbulk.ColumnMappings.Add("slope", "slope");
            objbulk.ColumnMappings.Add("ca", "ca");
            objbulk.ColumnMappings.Add("thal", "thal");
            objbulk.ColumnMappings.Add("smoking_hab", "smoking_hab");
            objbulk.ColumnMappings.Add("alcoholic", "alcoholic");
            objbulk.ColumnMappings.Add("physical_activity", "physical_activity");
            objbulk.ColumnMappings.Add("diet", "diet");
            objbulk.ColumnMappings.Add("obesity", "obesity");
            objbulk.ColumnMappings.Add("famhist", "famhist");
            objbulk.ColumnMappings.Add("stress", "stress");
            objbulk.ColumnMappings.Add("num", "num");
            objbulk.ColumnMappings.Add("id", "id");
            
            //inserting Datatable Records to DataBase    
            conn.Open();
            objbulk.WriteToServer(Exceldt);
            conn.Close();
        }


    }
}