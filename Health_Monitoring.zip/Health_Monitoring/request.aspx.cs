﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.IO;
using System.Text;
using System.Net.Mail;

public partial class request : System.Web.UI.Page
{
    SqlConnection _Conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connection_string"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Double QCount = 5;
            if (QCount == 5)
            {
                int bpm = Convert.ToInt32(Request.QueryString["bpm"].ToString());
                double btemp = Convert.ToDouble(Request.QueryString["btemp"].ToString());
                //double rtemp = Convert.ToDouble(Request.QueryString["rtemp"].ToString());
                //double hum = Convert.ToDouble(Request.QueryString["hum"].ToString());
                int userid = Convert.ToInt32(Request.QueryString["user_id"].ToString());

                SqlCommand objCmd = new SqlCommand("insert into Data(bpm,btemp,DateAdded,user_id)values(@bpm, @btemp,@DateAdded,@user_id)", _Conn);
                objCmd.Parameters.Add("@bpm", SqlDbType.Int).Value = bpm;
                //objCmd.Parameters.Add("@hum", SqlDbType.Float).Value = hum;
                objCmd.Parameters.Add("@btemp", SqlDbType.Float).Value = btemp;
                //objCmd.Parameters.Add("@rtemp", SqlDbType.Float).Value = rtemp;
                objCmd.Parameters.Add("@DateAdded", SqlDbType.DateTime).Value = DateTime.Now.AddMinutes(330);
                objCmd.Parameters.Add("@user_id", SqlDbType.Int).Value = userid;
                objCmd.CommandType = CommandType.Text;
                _Conn.Open();
                var Result = objCmd.ExecuteNonQuery();
                _Conn.Close();

                SqlCommand cmdGet = new SqlCommand("select min_bpm, max_bpm, min_temp, max_temp from NotificationData", _Conn);
                SqlDataAdapter daGet = new SqlDataAdapter(cmdGet);
                DataTable dt = new DataTable();
                daGet.Fill(dt);
                Double min_bpm = 0;
                Double max_bpm = 0;
                Double min_temp=0;
                Double max_temp = 0;
                if (dt.Rows.Count > 0)
                {
                    min_bpm = Convert.ToInt32(dt.Rows[0]["min_bpm"]);
                    max_bpm = Convert.ToInt32(dt.Rows[0]["max_bpm"]);
                    min_temp = Convert.ToInt32(dt.Rows[0]["min_bpm"]);
                    max_temp = Convert.ToInt32(dt.Rows[0]["max_bpm"]);

                    if (bpm < min_bpm)
                    {


                        WebRequest MyRssRequest = WebRequest.Create("https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=c5a0a9b5-24a5-49b7-9a45-77a9ab765f99&senderid=SMSTST&channel=1&DCS=0&flashsms=0&number=9920534221&text=%20Health%20Abnormal%20&route=13");
                        WebResponse MyRssResponse = MyRssRequest.GetResponse();
                        Stream MyRssStream = MyRssResponse.GetResponseStream();


                      //  string no = PhoneNumber;
                        ////string url =
                        ////    "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=Heart rate abnormal&fl=0";
                        ////var res = fileGetContents(url);

                        //WebRequest MyRssRequest = WebRequest.Create("https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=c5a0a9b5-24a5-49b7-9a45-77a9ab765f08&senderid=TESTIN&channel=1&DCS=0&flashsms=0&number=" + no + "&text=Heart rate abnormal!!!");
                        //WebResponse MyRssResponse = MyRssRequest.GetResponse();
                        //Stream MyRssStream = MyRssResponse.GetResponseStream();

                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("my-demo.in");

                        mail.From = new MailAddress("test@my-demo.in");
                        mail.Subject = "Alert";
                        mail.To.Add("nisarmiloni@gmail.com");
                        mail.Body = "Health Abnormal!!";

                        SmtpServer.Port = 25;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

                        SmtpServer.Send(mail);

                        //SmtpClient SmtpServer = new SmtpClient();
                        //MailMessage mail = new MailMessage();
                        //SmtpServer.Credentials = new System.Net.NetworkCredential("sanketdivadkar7@gmail.com", "sanketh1234");
                        //SmtpServer.Port = 587;
                        //SmtpServer.EnableSsl = true;
                        //SmtpServer.Host = "smtp.gmail.com";
                        //mail = new MailMessage();
                        //mail.From = new MailAddress("sanketdivadkar7@gmail.com");

                        //mail.To.Add(Email);
                        //mail.Subject = "Alert";
                        //mail.Body = "Heart rate abnormal";
                        //SmtpServer.Send(mail);
                    }
                    if (bpm > max_bpm)
                    {
                        //string no = PhoneNumber;
                        //string url =
                        //    "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=Heart rate abnormal&fl=0";
                        //var res = fileGetContents(url);
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("my-demo.in");

                        mail.From = new MailAddress("test@my-demo.in");
                        mail.Subject = "Alert";
                        mail.To.Add("purveshdave619@gmail.com");
                        mail.Body = "Health Abnormal!!";

                        SmtpServer.Port = 25;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

                        SmtpServer.Send(mail);
                    }
                    if (btemp < min_temp)
                    {
                        //string no = PhoneNumber;
                        //string url =
                        //    "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=Heart rate abnormal&fl=0";
                        //var res = fileGetContents(url);
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("my-demo.in");

                        mail.From = new MailAddress("test@my-demo.in");
                        mail.Subject = "Alert";
                        mail.To.Add("purveshdave619@gmail.com");
                        mail.Body = "Health Abnormal!!";

                        SmtpServer.Port = 25;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

                        SmtpServer.Send(mail);
                    }
                    if (btemp > max_temp)
                    {
                        //string no = PhoneNumber;
                        //string url =
                        //    "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=Heart rate abnormal&fl=0";
                        //var res = fileGetContents(url);
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtpServer = new SmtpClient("my-demo.in");

                        mail.From = new MailAddress("test@my-demo.in");
                        mail.Subject = "Alert";
                        mail.To.Add("purveshdave619@gmail.com");
                        mail.Body = "Health Abnormal!!";

                        SmtpServer.Port = 25;
                        SmtpServer.Credentials = new System.Net.NetworkCredential("test@my-demo.in", "Test@123");

                        SmtpServer.Send(mail);
                    }
                }
                if (Result.ToString() == "1")
                {
                    Response.Write("*Success=1");
                    //string json = "{\"succ\":\"101\"}";
                    //Response.Clear();
                    //Response.ContentType = "application/json; charset=utf-8";
                    //Response.Write(json);
                    //Response.End();
                    //HttpContext.Current.ApplicationInstance.CompleteRequest();
                }

                //if (sw == 1)
                //{
                //    string url = "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=9167297927&sid=WEBSMS&msg=I Am&fl=0";
                //    var res = fileGetContents(url);
                //}
            }
            //else if (QCount == 4)
            //{
            //    Double bpm = Convert.ToDouble32(Request.QueryString["bpm"].ToString());
            //    Double hum = Convert.ToDouble32(Request.QueryString["hum"].ToString());
            //    Double sw = Convert.ToDouble32((Request.QueryString["sw"]).ToString());
            //    Double user_id = Convert.ToDouble32(Request.QueryString["user_id"].ToString());

            //    SqlDataAdapter da = new SqlDataAdapter("select * from User_Master where user_id=@user_Id", _Conn);
            //    da.SelectCommand.Parameters.AddWithValue("@user_id", user_id);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds);
            //    string PhoneNumber = ds.Tables[0].Rows[0]["contact_no"].ToString();
            //    string Email = ds.Tables[0].Rows[0]["email_id"].ToString();

            //    SqlCommand objCmd =
            //        new SqlCommand(
            //            "insert Doubleo Data(bpm, hum,DateAdded,sw,user_id)values(@bpm, @hum,@DateAdded,@sw,@user_id)",
            //            _Conn);
            //    objCmd.Parameters.Add("@bpm", SqlDbType.Double).Value = bpm;
            //    objCmd.Parameters.Add("@hum", SqlDbType.Double).Value = hum;
            //    objCmd.Parameters.Add("@DateAdded", SqlDbType.DateTime).Value = DateTime.Now.AddMinutes(330);
            //    objCmd.Parameters.Add("@sw", SqlDbType.Double).Value = sw;
            //    objCmd.Parameters.Add("@user_id", SqlDbType.Double).Value = user_id;
            //    objCmd.CommandType = CommandType.Text;
            //    _Conn.Open();
            //    var Result = objCmd.ExecuteNonQuery();
            //    _Conn.Close();
            //    SqlCommand cmdGet = new SqlCommand("select min_bpm, max_bpm ,min_temp,max_temp from NotificationData", _Conn);
            //    SqlDataAdapter daGet = new SqlDataAdapter(cmdGet);
            //    DataTable dt = new DataTable();
            //    daGet.Fill(dt);
            //    Double min_bpm = 0; Double max_bpm = 0;
            //    Double min_temp = 0; Double max_temp = 0;

            //    if (dt.Rows.Count > 0)
            //    {
            //        min_bpm = Convert.ToDouble32(dt.Rows[0]["min_bpm"]);
            //        max_bpm = Convert.ToDouble32(dt.Rows[0]["max_bpm"]);
            //        min_temp = Convert.ToDouble32(dt.Rows[0]["min_temp"]);
            //        max_temp = Convert.ToDouble32(dt.Rows[0]["max_temp"]);
            //    }
            //    if (Result.ToString() == "1")
            //    {
            //        Response.Write("*Success=1");
            //    }

            //    if (sw == 1)
            //    {
            //        string url = "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=776308&to=" + PhoneNumber + "&sid=WEBSMS&msg=Patient, Alert messege is comming from your device. Please as soon as contact to nearest helpdesk&fl=0";
            //        var res = fileGetContents(url);
            //    }
          
            //    if (hum < min_temp)
            //    {
            //        string no = PhoneNumber;
            //        string url =
            //            "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=Low Temp &fl=0";
            //        var res = fileGetContents(url);
            //        SmtpClient SmtpServer = new SmtpClient();
            //        MailMessage mail = new MailMessage();
            //        SmtpServer.Credentials = new System.Net.NetworkCredential("sanketdivadkar7@gmail.com", "sanketh1234");
            //        SmtpServer.Port = 587;
            //        SmtpServer.EnableSsl = true;
            //        SmtpServer.Host = "smtp.gmail.com";
            //        mail = new MailMessage();
            //        mail.From = new MailAddress("sanketdivadkar7@gmail.com");

            //        mail.To.Add(Email);
            //        mail.Subject = "Alert";
            //        mail.Body = "Low Temp";
            //        SmtpServer.Send(mail);
            //    }
            //    if (hum > max_temp)
            //    {
            //        string no = PhoneNumber;
            //        string url =
            //            "http://login.smsgatewayhub.com/smsapi/pushsms.aspx?user=chDoublean&pwd=Passw0rd&to=" + no + "&sid=WEBSMS&msg=High Temp&fl=0";
            //        var res = fileGetContents(url);
            //        SmtpClient SmtpServer = new SmtpClient();
            //        MailMessage mail = new MailMessage();
            //        SmtpServer.Credentials = new System.Net.NetworkCredential("sanketdivadkar7@gmail.com", "sanketh1234");
            //        SmtpServer.Port = 587;
            //        SmtpServer.EnableSsl = true;
            //        SmtpServer.Host = "smtp.gmail.com";
            //        mail = new MailMessage();
            //        mail.From = new MailAddress("sanketdivadkar7@gmail.com");

            //        mail.To.Add(Email);
            //        mail.Subject = "Alert";
            //        mail.Body = "High Temp";
            //        SmtpServer.Send(mail);
            //    }
            //}

        }

    }
    protected static string fileGetContents(string fileName)
    {
        var sContents = string.Empty;
        var me = string.Empty;
        try
        {
            if (fileName.ToLower().IndexOf("http:") > -1)
            {
                var wc = new WebClient();
                var response = wc.DownloadData(fileName);
                sContents = Encoding.ASCII.GetString(response);

            }
            else
            {
                var sr = new StreamReader(fileName);
                sContents = sr.ReadToEnd();
                sr.Close();
            }
        }
        catch { sContents = "unable to connect to server "; }
        return sContents;
    }
}