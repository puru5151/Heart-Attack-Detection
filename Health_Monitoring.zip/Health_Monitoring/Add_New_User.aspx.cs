﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Add_New_User : System.Web.UI.Page
{
    public static string cs = WebConfigurationManager.ConnectionStrings["connection_string"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["action"] == "edit" && this.IsPostBack == false)
        {
            string user_id = Request.QueryString["user_id"];
            DataTable dt1 = new DataTable();
            string select_query = "Select * from dataset where id='" + user_id + "'";
            dt1 = Database.GetData(select_query);
            txtfull_name.Text = dt1.Rows[0]["Patient_name"].ToString();
            txtage.Text = dt1.Rows[0]["age"].ToString();
           // txtsex.Text = dt1.Rows[0]["sex"].ToString();
          //  txtcp.Text = dt1.Rows[0]["cp"].ToString();
            txttrestbps.Text = dt1.Rows[0]["trestbps"].ToString();
            txtchol.Text = dt1.Rows[0]["chol"].ToString();
          //  txtfbs.Text = dt1.Rows[0]["fbs"].ToString();
          //  txtrestcg.Text = dt1.Rows[0]["restecg"].ToString();
            txtthalach.Text = dt1.Rows[0]["thalach"].ToString();
          //  txtexang.Text = dt1.Rows[0]["exang"].ToString();
            txtoldpeak.Text = dt1.Rows[0]["oldpeak"].ToString();
          //  txtslope.Text = dt1.Rows[0]["slope"].ToString();
          //  txtca.Text = dt1.Rows[0]["ca"].ToString();
          //  txtthal.Text = dt1.Rows[0]["thal"].ToString();
           // txtsmoke.Text = dt1.Rows[0]["smoking_hab"].ToString();
          //  txtstres.Text = dt1.Rows[0]["alcoholic"].ToString();
          //  txtphysical.Text = dt1.Rows[0]["physical_activity"].ToString();
          //  txtdiet.Text = dt1.Rows[0]["diet"].ToString();
         //   txtobesity.Text = dt1.Rows[0]["obesity"].ToString();
          //  txtfamhist.Text = dt1.Rows[0]["famhist"].ToString();
          //  txtfamhist.Text = dt1.Rows[0]["stress"].ToString();
          //  txtnum.Text = dt1.Rows[0]["num"].ToString();
           



        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["action"] == "edit")
        {
            string user_id = Request.QueryString["user_id"];
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("update dbo.dataset1 set Patient_name=@Patient_name,age=@age,sex=@sex,cp=@cp,trestbps=@trestbps,chol=@chol,fbs=@fbs,restecg=@restecg,thalach=@thalach,exang=@exang,oldpeak=@oldpeak,slope=@slope,ca=@ca,thal=@thal,smoking_hab=@smoking_hab,alcoholic=@alcoholic,physical_activity=@physical_activity,diet=@diet,obesity=@obesity,famhist=@famhist,stress=@stress,num=@num where id = @id", con);
            cmd.Parameters.AddWithValue("@id", user_id);
            cmd.Parameters.AddWithValue("@Patient_name", txtfull_name.Text);
            cmd.Parameters.AddWithValue("@age", txtage.Text);
            cmd.Parameters.AddWithValue("@sex", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@cp", DropDownList2.SelectedValue);
            cmd.Parameters.AddWithValue("@trestbps", txttrestbps.Text);
            cmd.Parameters.AddWithValue("@chol", txtchol.Text);
            cmd.Parameters.AddWithValue("@fbs", DropDownList3.SelectedValue);
            cmd.Parameters.AddWithValue("@restecg", DropDownList4.SelectedValue);
            cmd.Parameters.AddWithValue("@thalach", txtthalach.Text);
            cmd.Parameters.AddWithValue("@exang", DropDownList5.SelectedValue);
            cmd.Parameters.AddWithValue("@oldpeak", txtoldpeak.Text);
            cmd.Parameters.AddWithValue("@slope", DropDownList6.SelectedValue);
            cmd.Parameters.AddWithValue("@ca", DropDownList7.SelectedValue);
            cmd.Parameters.AddWithValue("@thal", DropDownList8.SelectedValue);
            cmd.Parameters.AddWithValue("@smoking_hab", DropDownList9.SelectedValue);
            cmd.Parameters.AddWithValue("@alcoholic", DropDownList10.SelectedValue);
            cmd.Parameters.AddWithValue("@physical_activity", DropDownList14.SelectedValue);
            cmd.Parameters.AddWithValue("@diet", DropDownList11.SelectedValue);
            cmd.Parameters.AddWithValue("@obesity", DropDownList15.SelectedValue);
            cmd.Parameters.AddWithValue("@famhist", DropDownList12.SelectedValue);
            cmd.Parameters.AddWithValue("@stress", DropDownList13.SelectedValue);
            cmd.Parameters.AddWithValue("@num", DropDownList16.SelectedValue);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Manage_Users.aspx?msg=update");
        }
        else
        {
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("insert into dbo.dataset1(Patient_name,age,sex,cp,trestbps,chol,fbs,restecg,thalach,exang,oldpeak,slope,ca,thal,smoking_hab,alcoholic,physical_activity,diet,obesity,famhist,stress,num)values (@Patient_name,@age,@sex,@cp,@trestbps,@chol,@fbs,@restecg,@thalach,@exang,@oldpeak,@slope,@ca,@thal,@smoking_hab,@alcoholic,@physical_activity,@diet,@obesity,@famhist,@stress,@num)", con);
            cmd.Parameters.AddWithValue("@Patient_name", txtfull_name.Text);
            cmd.Parameters.AddWithValue("@age", txtage.Text);
            cmd.Parameters.AddWithValue("@sex", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@cp", DropDownList2.SelectedValue);
            cmd.Parameters.AddWithValue("@trestbps",txttrestbps.Text);
            cmd.Parameters.AddWithValue("@chol",txtchol.Text);
            cmd.Parameters.AddWithValue("@fbs", DropDownList3.SelectedValue);
            cmd.Parameters.AddWithValue("@restecg", DropDownList4.SelectedValue);
            cmd.Parameters.AddWithValue("@thalach",txtthalach.Text);
            cmd.Parameters.AddWithValue("@exang", DropDownList5.SelectedValue);
            cmd.Parameters.AddWithValue("@oldpeak",txtoldpeak.Text);
            cmd.Parameters.AddWithValue("@slope", DropDownList6.SelectedValue);
            cmd.Parameters.AddWithValue("@ca", DropDownList7.SelectedValue);
            cmd.Parameters.AddWithValue("@thal", DropDownList8.SelectedValue);
            cmd.Parameters.AddWithValue("@smoking_hab", DropDownList9.SelectedValue);
            cmd.Parameters.AddWithValue("@alcoholic", DropDownList10.SelectedValue);
            cmd.Parameters.AddWithValue("@physical_activity", DropDownList14.SelectedValue);
            cmd.Parameters.AddWithValue("@diet", DropDownList11.SelectedValue);
            cmd.Parameters.AddWithValue("@obesity", DropDownList15.SelectedValue);
            cmd.Parameters.AddWithValue("@famhist", DropDownList12.SelectedValue);
            cmd.Parameters.AddWithValue("@stress", DropDownList13.SelectedValue);
            cmd.Parameters.AddWithValue("@num", DropDownList16.SelectedValue);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            
            
    
            Response.Redirect("Manage_Users.aspx?msg=add");

        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manage_Users.aspx");
    }
}