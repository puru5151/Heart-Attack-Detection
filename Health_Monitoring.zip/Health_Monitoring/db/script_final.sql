USE [master]
GO
/****** Object:  Database [health_moni]    Script Date: 25-04-2019 18:50:56 ******/
CREATE DATABASE [health_moni]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'health_moni', FILENAME = N'D:\Microsoft SQL Server\DATA\health_moni.mdf' , SIZE = 3328KB , MAXSIZE = 5242880KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'health_moni_log', FILENAME = N'D:\Microsoft SQL Server\DATA\health_moni_log.ldf' , SIZE = 2048KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [health_moni] SET COMPATIBILITY_LEVEL = 110
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [health_moni].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [health_moni] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [health_moni] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [health_moni] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [health_moni] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [health_moni] SET ARITHABORT OFF 
GO
ALTER DATABASE [health_moni] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [health_moni] SET AUTO_CREATE_STATISTICS ON 
GO
ALTER DATABASE [health_moni] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [health_moni] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [health_moni] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [health_moni] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [health_moni] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [health_moni] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [health_moni] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [health_moni] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [health_moni] SET  ENABLE_BROKER 
GO
ALTER DATABASE [health_moni] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [health_moni] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [health_moni] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [health_moni] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [health_moni] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [health_moni] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [health_moni] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [health_moni] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [health_moni] SET  MULTI_USER 
GO
ALTER DATABASE [health_moni] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [health_moni] SET DB_CHAINING OFF 
GO
ALTER DATABASE [health_moni] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [health_moni] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
USE [health_moni]
GO
/****** Object:  User [huser3]    Script Date: 25-04-2019 18:50:56 ******/
CREATE USER [huser3] FOR LOGIN [huser3] WITH DEFAULT_SCHEMA=[huser3]
GO
ALTER ROLE [db_ddladmin] ADD MEMBER [huser3]
GO
ALTER ROLE [db_backupoperator] ADD MEMBER [huser3]
GO
ALTER ROLE [db_datareader] ADD MEMBER [huser3]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [huser3]
GO
/****** Object:  Schema [huser3]    Script Date: 25-04-2019 18:50:56 ******/
CREATE SCHEMA [huser3]
GO
/****** Object:  Table [dbo].[Admin_Login]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Admin_Login](
	[admin_id] [int] IDENTITY(1,1) NOT NULL,
	[username] [nvarchar](50) NULL,
	[password] [nvarchar](50) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Data]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Data](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[bpm] [int] NULL,
	[DateAdded] [datetime] NULL,
	[user_id] [int] NULL,
	[btemp] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[id3_compare]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[id3_compare](
	[pid] [int] NULL,
	[result] [varchar](50) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[naive_compare]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[naive_compare](
	[pid] [int] NULL,
	[result] [varchar](50) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[NotificationData]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[NotificationData](
	[min_bpm] [int] NOT NULL,
	[max_bpm] [int] NOT NULL,
	[min_temp] [int] NOT NULL,
	[max_temp] [int] NOT NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Sheet1$]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Sheet1$](
	[age] [float] NULL,
	[sex] [float] NULL,
	[cp] [float] NULL,
	[trestbps] [float] NULL,
	[chol] [float] NULL,
	[fbs] [float] NULL,
	[restecg] [float] NULL,
	[thalach] [float] NULL,
	[exang] [float] NULL,
	[oldpeak] [float] NULL,
	[slope] [float] NULL,
	[ca] [float] NULL,
	[thal] [float] NULL,
	[num] [varchar](50) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[User_Master]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User_Master](
	[user_id] [int] IDENTITY(1,1) NOT NULL,
	[full_name] [nvarchar](50) NULL,
	[email_id] [nvarchar](50) NULL,
	[contact_no] [nvarchar](50) NULL,
	[address] [nvarchar](max) NULL,
	[Password] [nvarchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [huser3].[dataset]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [huser3].[dataset](
	[Patient_name] [varchar](50) NULL,
	[age] [float] NULL,
	[sex] [float] NULL,
	[cp] [float] NULL,
	[trestbps] [float] NULL,
	[chol] [float] NULL,
	[fbs] [float] NULL,
	[restecg] [float] NULL,
	[thalach] [float] NULL,
	[exang] [float] NULL,
	[oldpeak] [float] NULL,
	[slope] [float] NULL,
	[ca] [float] NULL,
	[thal] [float] NULL,
	[smoking_hab] [float] NULL,
	[alcoholic] [float] NULL,
	[physical_activity] [float] NULL,
	[diet] [float] NULL,
	[obesity] [float] NULL,
	[famhist] [float] NULL,
	[stress] [float] NULL,
	[num] [varchar](50) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [huser3].[temp_z]    Script Date: 25-04-2019 18:50:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [huser3].[temp_z](
	[status] [varchar](50) NULL,
	[value_] [float] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[Admin_Login] ON 

INSERT [dbo].[Admin_Login] ([admin_id], [username], [password]) VALUES (1, N'admin', N'admin')
SET IDENTITY_INSERT [dbo].[Admin_Login] OFF
SET IDENTITY_INSERT [dbo].[Data] ON 

INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (1, 69, CAST(0x0000AA2200AE6547 AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (2, 59, CAST(0x0000AA2200AEAB3D AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (3, 3, CAST(0x0000AA2200AFBE35 AS DateTime), 1, 28)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (4, 50, CAST(0x0000AA2200B9A35F AS DateTime), 1, 26)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (5, 61, CAST(0x0000AA2200B9EA45 AS DateTime), 1, 26)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (16, 57, CAST(0x0000AA2200C5D299 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (17, 68, CAST(0x0000AA2200C6195E AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (18, 61, CAST(0x0000AA2200C65ED1 AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (19, 64, CAST(0x0000AA2200C6A783 AS DateTime), 1, 35)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (20, 56, CAST(0x0000AA2200C6EDD7 AS DateTime), 1, 35)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (21, 44, CAST(0x0000AA2200C736B7 AS DateTime), 1, 31)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (22, 41, CAST(0x0000AA2200C77A3F AS DateTime), 1, 28)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (23, 0, CAST(0x0000AA2200C7C027 AS DateTime), 1, 27)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (24, 56, CAST(0x0000AA2200C92789 AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (25, 60, CAST(0x0000AA2200C96CEC AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (26, 65, CAST(0x0000AA2200C9B411 AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (27, 64, CAST(0x0000AA2200C9FACF AS DateTime), 1, 35)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (28, 29, CAST(0x0000AA2200CA4171 AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (29, 9, CAST(0x0000AA2200CA88E6 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (30, 11, CAST(0x0000AA2200CACE1A AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (31, 62, CAST(0x0000AA2200CB5BBA AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (32, 57, CAST(0x0000AA2200CBA281 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (33, 65, CAST(0x0000AA2200CBEA66 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (34, 65, CAST(0x0000AA2200CC3152 AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (35, 58, CAST(0x0000AA2200CC76B9 AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (36, 65, CAST(0x0000AA2200CCBF2A AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (37, 65, CAST(0x0000AA2200CD063A AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (38, 64, CAST(0x0000AA2200CD4C8B AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (39, 24, CAST(0x0000AA2200CD91CC AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (40, 69, CAST(0x0000AA300145471F AS DateTime), 1, 34)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (41, 33, CAST(0x0000AA3001458C5F AS DateTime), 1, 33)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (42, 1, CAST(0x0000AA300148E252 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (43, 0, CAST(0x0000AA3001490644 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (44, 45, CAST(0x0000AA3001494D54 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (45, 24, CAST(0x0000AA30014993A5 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (46, 0, CAST(0x0000AA300149DA86 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (47, 0, CAST(0x0000AA30014A2087 AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (48, 0, CAST(0x0000AA30014A667A AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (49, 0, CAST(0x0000AA30014AACCE AS DateTime), 1, 32)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (50, 10, CAST(0x0000AA310008B9B4 AS DateTime), 1, 9)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (51, 10, CAST(0x0000AA3A00F536AE AS DateTime), 1, 9)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (6, 60, CAST(0x0000AA2200BA3159 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (7, 57, CAST(0x0000AA2200BA76D2 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (8, 0, CAST(0x0000AA2200BB0473 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (9, 1, CAST(0x0000AA2200BB50C4 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (10, 0, CAST(0x0000AA2200BBD96B AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (11, 0, CAST(0x0000AA2200BC1E31 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (12, 0, CAST(0x0000AA2200BC632A AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (13, 0, CAST(0x0000AA2200BCA9F4 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (14, 0, CAST(0x0000AA2200BCF340 AS DateTime), 1, 25)
INSERT [dbo].[Data] ([id], [bpm], [DateAdded], [user_id], [btemp]) VALUES (15, 0, CAST(0x0000AA2200BD3DBD AS DateTime), 1, 25)
SET IDENTITY_INSERT [dbo].[Data] OFF
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (4, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (8, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (4, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (12, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (12, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (13, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (11, N'4')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (8, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (8, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (4, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (3, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (12, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (12, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (13, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (7, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (8, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (9, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (10, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (11, N'4')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (12, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (13, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (14, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (14, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (15, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (15, N'1')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (11, N'4')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (4, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (4, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (5, N'2')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (1, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (6, N'3')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[id3_compare] ([pid], [result]) VALUES (2, N'0')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (1, N'2')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (2, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (3, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (4, N'1')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (5, N'3')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (6, N'0')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (8, N'0')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (3, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (4, N'1')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (12, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (12, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (12, N'4')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (2, N'1')
INSERT [dbo].[naive_compare] ([pid], [result]) VALUES (2, N'1')
INSERT [dbo].[NotificationData] ([min_bpm], [max_bpm], [min_temp], [max_temp]) VALUES (80, 100, 10, 40)
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 1, 1, 145, 233, 1, 2, 150, 0, 2.3, 3, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 4, 160, 286, 0, 2, 108, 1, 1.5, 2, 3, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 4, 120, 229, 0, 2, 129, 1, 2.6, 2, 2, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (37, 1, 3, 130, 250, 0, 0, 187, 0, 3.5, 3, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 0, 2, 130, 204, 0, 2, 172, 0, 1.4, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 2, 120, 236, 0, 0, 178, 0, 0.8, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 140, 268, 0, 2, 160, 0, 3.6, 3, 2, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 0, 4, 120, 354, 0, 0, 163, 1, 0.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 1, 4, 130, 254, 0, 2, 147, 0, 1.4, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 1, 4, 140, 203, 1, 2, 155, 1, 3.1, 3, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 140, 192, 0, 0, 148, 0, 0.4, 2, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 0, 2, 140, 294, 0, 2, 153, 0, 1.3, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 3, 130, 256, 1, 2, 142, 1, 0.6, 2, 1, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 2, 120, 263, 0, 0, 173, 0, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 3, 172, 199, 1, 0, 162, 0, 0.5, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 3, 150, 168, 0, 0, 174, 0, 1.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 2, 110, 229, 0, 0, 168, 0, 1, 3, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 140, 239, 0, 0, 160, 0, 1.2, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 0, 3, 130, 275, 0, 0, 139, 0, 0.2, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (49, 1, 2, 130, 266, 0, 0, 171, 0, 0.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 1, 110, 211, 0, 2, 144, 1, 1.8, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 1, 150, 283, 1, 2, 162, 0, 1, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 2, 120, 284, 0, 2, 160, 0, 1.8, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 3, 132, 224, 0, 2, 173, 0, 3.2, 1, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 130, 206, 0, 2, 132, 1, 2.4, 2, 2, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 0, 3, 120, 219, 0, 0, 158, 0, 1.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 3, 120, 340, 0, 0, 172, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 0, 1, 150, 226, 0, 0, 114, 0, 2.6, 3, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 4, 150, 247, 0, 0, 171, 0, 1.5, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (40, 1, 4, 110, 167, 0, 2, 114, 1, 2, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (69, 0, 1, 140, 239, 0, 0, 151, 0, 1.8, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 117, 230, 1, 0, 160, 1, 1.4, 1, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 3, 140, 335, 0, 0, 158, 0, 0, 1, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 135, 234, 0, 0, 161, 0, 0.5, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 3, 130, 233, 0, 0, 179, 1, 0.4, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 4, 140, 226, 0, 0, 178, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 4, 120, 177, 0, 2, 120, 1, 2.5, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 150, 276, 0, 2, 112, 1, 0.6, 2, 1, 6, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 1, 4, 132, 353, 0, 0, 132, 1, 1.2, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 3, 150, 243, 1, 0, 137, 1, 1, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 0, 4, 150, 225, 0, 2, 114, 0, 1, 2, 3, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (40, 1, 1, 140, 199, 0, 0, 178, 1, 1.4, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (71, 0, 2, 160, 302, 0, 0, 162, 0, 0.4, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 3, 150, 212, 1, 0, 157, 0, 1.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 0, 4, 130, 330, 0, 2, 169, 0, 0, 1, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 3, 112, 230, 0, 2, 165, 0, 2.5, 2, 1, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 3, 110, 175, 0, 0, 123, 0, 0.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 1, 4, 150, 243, 0, 2, 128, 0, 2.6, 2, 0, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 0, 3, 140, 417, 1, 2, 157, 0, 0.8, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 1, 3, 130, 197, 1, 2, 152, 0, 1.2, 3, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 0, 2, 105, 198, 0, 0, 168, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 1, 4, 120, 177, 0, 0, 140, 0, 0.4, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 4, 112, 290, 0, 2, 153, 0, 0, 1, 1, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 2, 130, 219, 0, 2, 188, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 130, 253, 0, 0, 144, 1, 1.4, 1, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 124, 266, 0, 2, 109, 1, 2.2, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 1, 3, 140, 233, 0, 0, 163, 0, 0.6, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 4, 110, 172, 0, 2, 158, 0, 0, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 3, 125, 273, 0, 2, 152, 0, 0.5, 3, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 1, 125, 213, 0, 2, 125, 1, 1.4, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 0, 4, 130, 305, 0, 0, 142, 1, 1.2, 2, 0, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 0, 3, 142, 177, 0, 2, 160, 1, 1.4, 3, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 128, 216, 0, 2, 131, 1, 2.2, 2, 3, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 0, 3, 135, 304, 1, 0, 170, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 120, 188, 0, 0, 113, 0, 1.4, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 145, 282, 0, 2, 142, 1, 2.8, 2, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 3, 140, 185, 0, 2, 155, 0, 3, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 3, 150, 232, 0, 2, 165, 0, 1.6, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 170, 326, 0, 2, 140, 1, 3.4, 3, 0, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 1, 3, 150, 231, 0, 0, 147, 0, 3.6, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 0, 3, 155, 269, 0, 0, 148, 0, 0.8, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 4, 125, 254, 1, 0, 163, 0, 0.2, 2, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 1, 4, 120, 267, 0, 0, 99, 1, 1.8, 2, 2, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 1, 4, 110, 248, 0, 2, 158, 0, 0.6, 1, 2, 6, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 4, 110, 197, 0, 2, 177, 0, 0, 1, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 0, 3, 160, 360, 0, 2, 151, 0, 0.8, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 125, 258, 0, 2, 141, 1, 2.8, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 0, 3, 140, 308, 0, 2, 142, 0, 1.5, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 2, 130, 245, 0, 2, 180, 0, 0.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 150, 270, 0, 2, 111, 1, 0.8, 1, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 1, 4, 104, 208, 0, 2, 148, 1, 3, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 0, 4, 130, 264, 0, 2, 143, 0, 0.4, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (39, 1, 3, 140, 321, 0, 2, 182, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (68, 1, 3, 180, 274, 1, 2, 150, 1, 1.6, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 2, 120, 325, 0, 0, 172, 0, 0.2, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 3, 140, 235, 0, 2, 180, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (47, 1, 3, 138, 257, 0, 2, 156, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 0, 3, 128, 216, 0, 2, 115, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 0, 4, 138, 234, 0, 2, 160, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 0, 3, 130, 256, 0, 2, 149, 0, 0.5, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 1, 4, 120, 302, 0, 2, 151, 0, 0.4, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 160, 164, 0, 2, 145, 0, 6.2, 3, 3, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 1, 3, 130, 231, 0, 0, 146, 0, 1.8, 2, 3, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 0, 3, 108, 141, 0, 0, 175, 0, 0.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 0, 3, 135, 252, 0, 2, 172, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 4, 128, 255, 0, 0, 161, 1, 0, 1, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 110, 239, 0, 2, 142, 1, 1.2, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 0, 4, 150, 258, 0, 2, 157, 0, 2.6, 2, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 2, 134, 201, 0, 0, 158, 0, 0.8, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 4, 122, 222, 0, 2, 186, 0, 0, 1, 0, 3, N'0')
GO
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 1, 4, 115, 260, 0, 2, 185, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (34, 1, 1, 118, 182, 0, 2, 174, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 0, 4, 128, 303, 0, 2, 159, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (71, 0, 3, 110, 265, 1, 2, 130, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (49, 1, 3, 120, 188, 0, 0, 139, 0, 2, 2, 3, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 2, 108, 309, 0, 0, 156, 0, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 140, 177, 0, 0, 162, 1, 0, 1, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 3, 128, 229, 0, 2, 150, 0, 0.4, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 4, 120, 260, 0, 0, 140, 1, 3.6, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (39, 1, 4, 118, 219, 0, 0, 140, 0, 1.2, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 0, 4, 145, 307, 0, 2, 146, 1, 1, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 4, 125, 249, 1, 2, 144, 1, 1.2, 2, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 1, 118, 186, 0, 2, 190, 0, 0, 2, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 0, 4, 132, 341, 1, 2, 136, 1, 3, 2, 0, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 3, 130, 263, 0, 0, 97, 0, 1.2, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 2, 135, 203, 0, 0, 132, 0, 0, 2, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 3, 140, 211, 1, 2, 165, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (35, 0, 4, 138, 183, 0, 0, 182, 0, 1.4, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 1, 4, 130, 330, 1, 2, 132, 1, 1.8, 1, 3, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 1, 4, 135, 254, 0, 2, 127, 0, 2.8, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 4, 130, 256, 1, 2, 150, 1, 0, 1, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 0, 4, 150, 407, 0, 2, 154, 0, 4, 2, 3, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 3, 100, 222, 0, 0, 143, 1, 1.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 1, 4, 140, 217, 0, 0, 111, 1, 5.6, 3, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (65, 1, 1, 138, 282, 1, 2, 174, 0, 1.4, 2, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 0, 2, 130, 234, 0, 2, 175, 0, 0.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 0, 4, 200, 288, 1, 2, 133, 1, 4, 3, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 110, 239, 0, 0, 126, 1, 2.8, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 2, 120, 220, 0, 0, 170, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 124, 209, 0, 0, 163, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 3, 120, 258, 0, 2, 147, 0, 0.4, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 3, 94, 227, 0, 0, 154, 1, 0, 1, 1, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (29, 1, 2, 130, 204, 0, 2, 202, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 4, 140, 261, 0, 2, 186, 1, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 0, 3, 122, 213, 0, 0, 165, 0, 0.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 0, 2, 135, 250, 0, 2, 161, 0, 1.4, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (70, 1, 4, 145, 174, 0, 0, 125, 1, 2.6, 3, 0, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 1, 2, 120, 281, 0, 2, 103, 0, 1.4, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (35, 1, 4, 120, 198, 0, 0, 130, 1, 1.6, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 3, 125, 245, 1, 2, 166, 0, 2.4, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 2, 140, 221, 0, 0, 164, 1, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 1, 170, 288, 0, 2, 159, 0, 0.2, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 2, 128, 205, 1, 0, 184, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 3, 125, 309, 0, 0, 131, 1, 1.8, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 3, 105, 240, 0, 2, 154, 1, 0.6, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (47, 1, 3, 108, 243, 0, 0, 152, 0, 0, 1, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 165, 289, 1, 2, 124, 0, 1, 2, 3, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 3, 112, 250, 0, 0, 179, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 1, 2, 128, 308, 0, 2, 170, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 0, 3, 102, 318, 0, 0, 160, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 1, 152, 298, 1, 0, 178, 0, 1.2, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 0, 4, 102, 265, 0, 2, 122, 0, 0.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 0, 3, 115, 564, 0, 2, 160, 0, 1.6, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 1, 4, 160, 289, 0, 2, 145, 1, 0.8, 2, 1, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 4, 120, 246, 0, 2, 96, 1, 2.2, 3, 1, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (70, 1, 4, 130, 322, 0, 2, 109, 0, 2.4, 2, 3, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 4, 140, 299, 0, 0, 173, 1, 1.6, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 125, 300, 0, 2, 171, 0, 0, 1, 2, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 1, 4, 140, 293, 0, 2, 170, 0, 1.2, 2, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (68, 1, 3, 118, 277, 0, 0, 151, 0, 1, 1, 1, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 1, 2, 101, 197, 1, 0, 156, 0, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (77, 1, 4, 125, 304, 0, 2, 162, 1, 0, 1, 3, 3, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 0, 3, 110, 214, 0, 0, 158, 0, 1.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 4, 100, 248, 0, 2, 122, 0, 1, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 3, 124, 255, 1, 0, 175, 0, 0, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 132, 207, 0, 0, 168, 1, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 3, 138, 223, 0, 0, 169, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 0, 2, 132, 288, 1, 2, 159, 1, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (35, 1, 4, 126, 282, 0, 2, 156, 1, 0, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 0, 2, 112, 160, 0, 0, 138, 0, 0, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (70, 1, 3, 160, 269, 0, 0, 112, 1, 2.9, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 1, 4, 142, 226, 0, 2, 111, 1, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 0, 4, 174, 249, 0, 0, 143, 1, 0, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 140, 394, 0, 2, 157, 0, 1.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 4, 145, 212, 0, 2, 132, 0, 2, 2, 2, 6, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 152, 274, 0, 0, 88, 1, 1.2, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 4, 108, 233, 1, 0, 147, 0, 0.1, 1, 3, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 4, 132, 184, 0, 2, 105, 1, 2.1, 2, 1, 6, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 3, 130, 315, 0, 0, 162, 0, 1.9, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 1, 3, 130, 246, 1, 2, 173, 0, 0, 1, 3, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (48, 1, 4, 124, 274, 0, 2, 166, 0, 0.5, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 0, 4, 134, 409, 0, 2, 150, 1, 1.9, 2, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 1, 148, 244, 0, 2, 178, 0, 0.8, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 1, 178, 270, 0, 2, 145, 0, 4.2, 3, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 0, 4, 158, 305, 0, 2, 161, 0, 0, 1, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 0, 2, 140, 195, 0, 0, 179, 0, 0, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 3, 120, 240, 1, 0, 194, 0, 0.8, 3, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 1, 2, 160, 246, 0, 0, 120, 1, 0, 2, 3, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 2, 192, 283, 0, 2, 195, 0, 0, 1, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (69, 1, 3, 140, 254, 0, 2, 146, 0, 2, 2, 3, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 1, 3, 129, 196, 0, 0, 163, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 1, 4, 140, 298, 0, 0, 122, 1, 4.2, 2, 3, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 4, 132, 247, 1, 2, 143, 1, 0.1, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 138, 294, 1, 0, 106, 0, 1.9, 2, 3, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (68, 0, 3, 120, 211, 0, 2, 115, 0, 1.5, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 4, 100, 299, 0, 2, 125, 1, 0.9, 2, 2, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (69, 1, 1, 160, 234, 1, 2, 131, 0, 0.1, 2, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 0, 4, 138, 236, 0, 2, 152, 1, 0.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 0, 2, 120, 244, 0, 0, 162, 0, 1.1, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 1, 160, 273, 0, 2, 125, 0, 0, 1, 0, 3, N'1')
GO
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 0, 4, 110, 254, 0, 2, 159, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 0, 4, 180, 325, 0, 0, 154, 1, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 3, 150, 126, 1, 0, 173, 0, 0.2, 1, 1, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 0, 3, 140, 313, 0, 0, 133, 0, 0.2, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 4, 110, 211, 0, 0, 161, 0, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 1, 4, 142, 309, 0, 2, 147, 1, 0, 2, 3, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 128, 259, 0, 2, 130, 1, 3, 2, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (50, 1, 4, 144, 200, 0, 2, 126, 1, 0.9, 2, 0, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 1, 2, 130, 262, 0, 0, 155, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 0, 4, 150, 244, 0, 0, 154, 1, 1.4, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (37, 0, 3, 120, 215, 0, 0, 170, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (38, 1, 1, 120, 231, 0, 0, 182, 1, 3.8, 2, 0, 7, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 3, 130, 214, 0, 2, 168, 0, 2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 0, 4, 178, 228, 1, 0, 165, 1, 1, 2, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 4, 112, 230, 0, 0, 160, 0, 0, 1, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 1, 120, 193, 0, 2, 162, 0, 1.9, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 0, 2, 105, 204, 0, 0, 172, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 0, 4, 138, 243, 0, 2, 152, 1, 0, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 0, 4, 130, 303, 0, 0, 122, 0, 2, 2, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 138, 271, 0, 2, 182, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 0, 3, 112, 268, 0, 2, 172, 1, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 0, 3, 108, 267, 0, 2, 167, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (39, 0, 3, 94, 199, 0, 0, 179, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (53, 1, 4, 123, 282, 0, 0, 95, 1, 2, 2, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 0, 4, 108, 269, 0, 0, 169, 1, 1.8, 2, 2, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (34, 0, 2, 118, 210, 0, 0, 192, 0, 0.7, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (47, 1, 4, 112, 204, 0, 0, 143, 0, 0.1, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 0, 3, 152, 277, 0, 0, 172, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 110, 206, 0, 2, 108, 1, 0, 2, 1, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 1, 4, 112, 212, 0, 2, 132, 1, 0.1, 1, 1, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 0, 3, 136, 196, 0, 2, 169, 0, 0.1, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 0, 4, 180, 327, 0, 1, 117, 1, 3.4, 2, 0, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (49, 1, 3, 118, 149, 0, 2, 126, 0, 0.8, 1, 3, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (74, 0, 2, 120, 269, 0, 2, 121, 1, 0.2, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 0, 3, 160, 201, 0, 0, 163, 0, 0, 1, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (54, 1, 4, 122, 286, 0, 2, 116, 1, 3.2, 2, 2, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 4, 130, 283, 1, 2, 103, 1, 1.6, 3, 0, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 1, 4, 120, 249, 0, 2, 144, 0, 0.8, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (49, 0, 2, 134, 271, 0, 0, 162, 0, 0, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 2, 120, 295, 0, 0, 162, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 2, 110, 235, 0, 0, 153, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 0, 2, 126, 306, 0, 0, 163, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (49, 0, 4, 130, 269, 0, 0, 163, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 1, 134, 234, 0, 0, 145, 0, 2.6, 2, 2, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 0, 3, 120, 178, 1, 0, 96, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 4, 120, 237, 0, 0, 71, 0, 1, 2, 0, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 100, 234, 0, 0, 156, 0, 0.1, 1, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (47, 1, 4, 110, 275, 0, 2, 118, 1, 1, 2, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 4, 125, 212, 0, 0, 168, 0, 1, 1, 2, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (62, 1, 2, 128, 208, 1, 2, 140, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 110, 201, 0, 0, 126, 1, 1.5, 2, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 146, 218, 0, 0, 105, 0, 2, 2, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 4, 128, 263, 0, 0, 105, 1, 0.2, 2, 1, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (51, 0, 3, 120, 295, 0, 2, 157, 0, 0.6, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (43, 1, 4, 115, 303, 0, 0, 181, 0, 1.2, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 0, 3, 120, 209, 0, 0, 173, 0, 0, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 0, 4, 106, 223, 0, 0, 142, 0, 0.3, 1, 2, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (76, 0, 3, 140, 197, 0, 1, 116, 0, 1.1, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (70, 1, 2, 156, 245, 0, 2, 143, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 2, 124, 261, 0, 0, 141, 0, 0.3, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 0, 3, 118, 242, 0, 0, 149, 0, 0.3, 2, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 2, 136, 319, 1, 2, 152, 0, 0, 1, 2, 3, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (60, 0, 1, 150, 240, 0, 0, 171, 0, 0.9, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 3, 120, 226, 0, 0, 169, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 4, 138, 166, 0, 2, 125, 1, 3.6, 2, 1, 3, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 4, 136, 315, 0, 0, 125, 1, 1.8, 2, 0, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (52, 1, 4, 128, 204, 1, 0, 156, 1, 1, 2, 0, 3, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 3, 126, 218, 1, 0, 134, 0, 2.2, 2, 1, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (40, 1, 4, 152, 223, 0, 0, 181, 0, 0, 1, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (42, 1, 3, 130, 180, 0, 0, 150, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 4, 140, 207, 0, 2, 138, 1, 1.9, 1, 1, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 1, 4, 160, 228, 0, 2, 138, 0, 2.3, 1, 0, 6, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (46, 1, 4, 140, 311, 0, 0, 120, 1, 1.8, 2, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (71, 0, 4, 112, 149, 0, 0, 125, 0, 1.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 1, 134, 204, 0, 0, 162, 0, 0.8, 1, 2, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (64, 1, 1, 170, 227, 0, 2, 155, 0, 0.6, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (66, 0, 3, 146, 278, 0, 2, 152, 0, 0, 2, 1, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (39, 0, 3, 138, 220, 0, 0, 152, 0, 0, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 2, 154, 232, 0, 2, 164, 0, 0, 1, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 4, 130, 197, 0, 0, 131, 0, 0.6, 2, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 110, 335, 0, 0, 143, 1, 3, 2, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (47, 1, 3, 130, 253, 0, 0, 179, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 0, 4, 128, 205, 0, 1, 130, 1, 2, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (35, 1, 2, 122, 192, 0, 0, 174, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (61, 1, 4, 148, 203, 0, 0, 161, 0, 0, 1, 1, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 4, 114, 318, 0, 1, 140, 0, 4.4, 3, 3, 6, N'4')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 0, 4, 170, 225, 1, 2, 146, 1, 2.8, 2, 2, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (58, 1, 2, 125, 220, 0, 0, 144, 0, 0.4, 2, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 2, 130, 221, 0, 2, 163, 0, 0, 1, 0, 7, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (56, 1, 2, 120, 240, 0, 0, 169, 0, 0, 3, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (67, 1, 3, 152, 212, 0, 2, 150, 0, 0.8, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (55, 0, 2, 132, 342, 0, 0, 166, 0, 1.2, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (44, 1, 4, 120, 169, 0, 0, 144, 1, 2.8, 3, 0, 6, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 1, 4, 140, 187, 0, 2, 144, 1, 4, 1, 2, 7, N'2')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (63, 0, 4, 124, 197, 0, 0, 136, 1, 0, 2, 0, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (41, 1, 2, 120, 157, 0, 0, 182, 0, 0, 1, 0, 3, N'0')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (59, 1, 4, 164, 176, 1, 2, 90, 0, 1, 2, 2, 6, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 0, 4, 140, 241, 0, 0, 123, 1, 0.2, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (45, 1, 1, 110, 264, 0, 0, 132, 0, 1.2, 2, 0, 7, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (68, 1, 4, 144, 193, 1, 0, 141, 0, 3.4, 2, 2, 7, N'2')
GO
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 1, 4, 130, 131, 0, 0, 115, 1, 1.2, 2, 1, 7, N'3')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (57, 0, 2, 130, 236, 0, 2, 174, 0, 0, 2, 1, 3, N'1')
INSERT [dbo].[Sheet1$] ([age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [num]) VALUES (38, 1, 3, 138, 175, 0, 0, 173, 0, 0, 1, 0, 3, N'0')
SET IDENTITY_INSERT [dbo].[User_Master] ON 

INSERT [dbo].[User_Master] ([user_id], [full_name], [email_id], [contact_no], [address], [Password]) VALUES (1, N'shailesh', N'shailesh@gmail.com', N'9221286927', N'kjkljklj', N'shailesh')
INSERT [dbo].[User_Master] ([user_id], [full_name], [email_id], [contact_no], [address], [Password]) VALUES (2, N'Nivrutikore', N'nivrutikore@gmail.com', N'9696325874', N'Pune', N'123456')
SET IDENTITY_INSERT [dbo].[User_Master] OFF
SET IDENTITY_INSERT [huser3].[dataset] ON 

INSERT [huser3].[dataset] ([Patient_name], [age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [smoking_hab], [alcoholic], [physical_activity], [diet], [obesity], [famhist], [stress], [num], [id]) VALUES (N'purvesh', 30, 1, 1, 120, 280, 1, 1, 160, 1, 200, 1, 2, 6, 1, 1, 1, 1, 1, 1, 1, N'0', 4)
INSERT [huser3].[dataset] ([Patient_name], [age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [smoking_hab], [alcoholic], [physical_activity], [diet], [obesity], [famhist], [stress], [num], [id]) VALUES (N'Miloni', 32, 0, 2, 130, 1.4, 1, 0, 125, 0, 11, 2, 1, 6, 0, 1, 1, 0, 2, 0, 1, N'3', 5)
INSERT [huser3].[dataset] ([Patient_name], [age], [sex], [cp], [trestbps], [chol], [fbs], [restecg], [thalach], [exang], [oldpeak], [slope], [ca], [thal], [smoking_hab], [alcoholic], [physical_activity], [diet], [obesity], [famhist], [stress], [num], [id]) VALUES (N'Shri', 45, 1, 1, 120, 1.4, 1, 1, 125, 0, 11, 1, 1, 3, 1, 1, 2, 1, 1, 1, 1, N'1', 6)
SET IDENTITY_INSERT [huser3].[dataset] OFF
INSERT [huser3].[temp_z] ([status], [value_]) VALUES (N'0', 1.6758776542920961E-08)
INSERT [huser3].[temp_z] ([status], [value_]) VALUES (N'2', 6.8938265419282235E-08)
INSERT [huser3].[temp_z] ([status], [value_]) VALUES (N'1', 9.9339560779544029E-08)
INSERT [huser3].[temp_z] ([status], [value_]) VALUES (N'3', 7.3602657382595611E-08)
INSERT [huser3].[temp_z] ([status], [value_]) VALUES (N'4', 1.9153810468197875E-08)
ALTER TABLE [dbo].[Data] ADD  CONSTRAINT [DF_Data_user_id]  DEFAULT ((1)) FOR [user_id]
GO
USE [master]
GO
ALTER DATABASE [health_moni] SET  READ_WRITE 
GO
