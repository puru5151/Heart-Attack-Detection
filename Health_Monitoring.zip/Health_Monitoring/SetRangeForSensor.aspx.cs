﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;

public partial class SetRangeForSensor : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["connection_string"].ConnectionString);
    SqlDataAdapter da = null;
    DataSet ds = null;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SetRange_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(txtminbpm.Text) <= Convert.ToInt32(txtMaxbpm.Text) && Convert.ToInt32(txtmintemp.Text) <= Convert.ToInt32(txtmaxtemp.Text))
        {
            SqlDataAdapter adp = new SqlDataAdapter("SELECT * FROM NotificationData", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                SqlCommand cmd = new SqlCommand("update NotificationData set min_bpm='" + txtminbpm.Text + "',max_bpm='" + txtMaxbpm.Text + "',min_temp='" + txtmintemp.Text + "',max_temp='" + txtmaxtemp.Text + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                SqlCommand cmd = new SqlCommand("insert into NotificationData values(@min_bpm,@max_bpm,@min_temp,@max_temp)", con);
                cmd.Parameters.AddWithValue("@min_bpm", Convert.ToInt32(txtminbpm.Text));
                cmd.Parameters.AddWithValue("@max_bpm", Convert.ToInt32(txtMaxbpm.Text));
                cmd.Parameters.AddWithValue("@min_temp", Convert.ToInt32(txtminbpm.Text));
                cmd.Parameters.AddWithValue("@max_temp", Convert.ToInt32(txtmaxtemp.Text));
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            txtMaxbpm.Text = "";
            txtmaxtemp.Text = "";
            txtminbpm.Text = "";
            txtmintemp.Text = "";
        }
        else
        {
            Response.Write("<script>alert('heart bit or teampreature value will be less than max value.')</script>");
            return;
        }


    }
}